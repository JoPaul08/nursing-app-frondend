
import './App.css';

function App() {
  return (
    <div className="App">
     <p>hello</p>
    </div>
  );
}

export default App;
